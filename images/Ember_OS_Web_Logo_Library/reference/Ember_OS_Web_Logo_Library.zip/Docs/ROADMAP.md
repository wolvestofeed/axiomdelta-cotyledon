# Ember OS Brand — Master Roadmap

Build phases for the Ember OS identity and its sub-brands. Each item is marked open [ ] or completed [x].

## Phase 1 — Ember OS web logo library
- [x] Stacked lockups from the original (full frame 1024, tight 704, 512, 256, JPG)
- [x] Square mark icon with the wordmark removed and background rebuilt (520 native, 1024 upscaled, 512–128)
- [x] Small icons with tighter crop (64/48/32/16) and favicon.ico
- [x] Wordmark on original background (624, 312)
- [x] Transparent wordmark: white, original gray, dark (full and small)
- [ ] Rob review and any re-crops

## Phase 2 — High-resolution / print
- [ ] High-res regeneration of the illustration on a plain background
- [ ] Rebuild library from the high-res source
- [ ] Transparent mark cutout
- [ ] Print-ready files

## Phase 3 — Brand system
- [ ] Color palette pulled from the illustration
- [ ] Typography spec alongside sub-brand fonts
- [ ] "Powered by Ember OS" endorsement lockup
- [ ] One-page brand guidelines

## Phase 4 — Muse Kitchen sub-brand
- [x] Master confirmed: Living Sprout tile (v1, Sept 2026)
- [ ] Swap "Impact OS" for the Ember endorsement in its lockups

## Phase 5 — Micro Farm sub-brand
- [ ] Brief, mark, wordmark, endorsed lockups

## Phase 6 — Rollout
- [ ] Replace logos in Muse Kitchen (getcomptable.com/muse) and the Micro Farm repo
- [ ] OG image and social avatars

---

## Update Log
- **2026-09-27** — Project started. Endorsed architecture decided; Muse Kitchen master confirmed as the Living Sprout tile. Vector redraw attempted and rejected (could not match the painted original). Built the web logo library v1 directly from the original: stacked lockups, square icon set with rebuilt background, favicon, wordmark on background, and transparent wordmarks.
