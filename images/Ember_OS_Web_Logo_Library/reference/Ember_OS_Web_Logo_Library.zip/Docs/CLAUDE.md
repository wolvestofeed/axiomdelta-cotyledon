# Ember OS Brand — CLAUDE.md

Project oversight, rules and instructions for the Ember OS identity and its sub-brands.

## What this project is
Ember OS is the operating-system brand under the AXiomDelta umbrella. Apps built on it keep their own marks and are endorsed "powered by Ember OS":
- **Muse Kitchen** (formerly "Impact OS")
- **Micro Farm** (microgreens and sprouts; same application as Muse Kitchen, new vocabulary and database)
- More apps later.

## Decisions
- 2026-09-27 — Endorsed brand architecture: each app has its own mark + "powered by Ember OS".
- 2026-09-27 — The painted original illustration is THE Ember OS logo. A vector redraw was tried and rejected: it could not match the original's photoreal detail. Do not substitute flat/vector interpretations.
- 2026-09-27 — Current scope is web/screen only. Print-grade files are deferred.
- Muse Kitchen's official logo is the Living Sprout tile only (soil layers, seedling, sun arc that doubles as a thermometer gauge). The MK monogram and whisk/sprout versions are not in use.

## Rules
1. `reference/ember-os-original-illustration.png` is the source of truth. Every file is derived from it; never edit the original.
2. The original is 1024 px. Anything larger is an upscale and must be labeled as such in the filename.
3. The square icon has the wordmark removed and the background rebuilt from the brushed texture below the mark. Keep that rebuilt background when making new crops.
4. Small icons (64 px and under) use a tighter crop so the mark reads.
5. If a high-resolution regeneration of the illustration becomes available, rebuild the whole library from it.
6. Keep the Docs trio current: ToDo for one-offs, Roadmap for phased build detail with an Update Log at the bottom.

## Type
EMBER: Montserrat Bold. OS: Montserrat Light.
