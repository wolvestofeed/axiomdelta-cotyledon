# Ember OS Brand — ToDo

One-off items waiting to be placed into the roadmap.

- [ ] Rob review of the web library v1
- [ ] Get a high-resolution regeneration of the illustration (4000 px+, plain background) for future print use
- [ ] Transparent-background mark cutout (needs the high-res source; the glow fringes on the 1024 file)
- [ ] Design the "powered by Ember OS" endorsement line
- [ ] Micro Farm: does it have a logo yet, or do we design one?
- [ ] Decide where the brand library lives (repo, Drive, or both)
