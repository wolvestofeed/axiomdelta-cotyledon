Ember OS - web logo library (v1, September 2026)
Built from the original illustration (1024 x 1024). Screen/web use; not intended for print.

stacked/   Mark + EMBER OS, stacked, on the original brushed-green background
  ember-os-stacked-1024.png         the original, full frame
  ember-os-stacked-tight-704.png    tighter framing, native resolution
  ember-os-stacked-512.png / .jpg, ember-os-stacked-256.png

icon/      Mark alone, square, on the original background (wordmark removed, background rebuilt)
  ember-mark-square-520.png         native resolution (largest true-detail version)
  ember-mark-square-1024-upscaled.png   2x upscale for retina/app-store slots; slightly soft
  512 / 256 / 192 / 180 (Apple touch) / 128
  64 / 48 / 32 / 16                 tighter crop so the mark reads at tiny sizes
  favicon.ico                       16, 32, 48, 64 bundled

wordmark/  EMBER OS alone
  ember-os-wordmark-on-background-624.png / -312.png   on the original background
  ember-os-wordmark-transparent-white(.png / -small)   for dark surfaces
  ember-os-wordmark-transparent-original-gray          the original's light gray
  ember-os-wordmark-transparent-dark                   for light surfaces

reference/ The untouched original.
Docs/      CLAUDE.md (rules), TODO.md (one-offs), ROADMAP.md (phases + update log)

Wordmark type: Montserrat Bold (EMBER) + Montserrat Light (OS).
